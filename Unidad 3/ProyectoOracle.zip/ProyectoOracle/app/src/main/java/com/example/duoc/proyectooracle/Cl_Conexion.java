package com.example.duoc.proyectooracle;

import java.sql.Connection;
import java.sql.DriverManager;

public class Cl_Conexion {
    public String driver, url, ip, bd, usr, pass;
    public Connection connection;

    public Cl_Conexion(String ip, String bd, String usr, String pass)
    {
        driver="oracle.jdbc.driver.OracleDriver";
        this.bd = bd;
        this.usr = usr;
        this.pass = pass;
        url=new String("jdbc:oracle:thin:@"+ip+":1521:"+bd);
        try{
            Class.forName(driver).newInstance();
            connection = DriverManager.getConnection(url,usr,pass);
            System.out.println("Conexion a la base de datos: "+bd+" exitosa");
        }catch(Exception ex){
            System.out.println("Error en la conexion: "+ex);
        }
        //Al llamar a la conexion se le debe dar la ip:10.0.2.2
    }
}
