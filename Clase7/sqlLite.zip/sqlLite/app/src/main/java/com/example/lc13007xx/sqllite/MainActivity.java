package com.example.lc13007xx.sqllite;

import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import com.example.lc13007xx.sqllite.conexion.ConexionHelper;

public class MainActivity extends AppCompatActivity {

    EditText txtPatente, txtNumChasis,txtColor;
    Spinner spModelo;
    Button btnGuardar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtPatente = findViewById(R.id.txtPatente);
        txtColor = findViewById(R.id.txtColor);
        txtNumChasis = findViewById(R.id.txtChasis);
        btnGuardar = findViewById(R.id.btnGuardar);
        btnGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ConexionHelper conexion=new ConexionHelper(getApplicationContext(),
                        "BDAutomotora", null,1);
                SQLiteDatabase bd=conexion.getWritableDatabase();

                //si la base de datos no es null
                if (bd!=null){
                    String patente=txtPatente.getText().toString();
                    int numChasis=Integer.parseInt(txtNumChasis.getText().toString());
                    String color=txtColor.getText().toString();
                    String modelo = spModelo.getSelectedItem().toString();
                    bd.execSQL("INSERT INTO AUTOMOVIL " +
                            "VALUES("+patente+", "+color+", "+modelo+")");
                    //debe tener un espacio depues de la  ", "
                    bd.close();
                }
            }
        });
    }
}
